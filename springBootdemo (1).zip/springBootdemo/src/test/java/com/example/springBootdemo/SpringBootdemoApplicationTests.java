package com.example.springBootdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
